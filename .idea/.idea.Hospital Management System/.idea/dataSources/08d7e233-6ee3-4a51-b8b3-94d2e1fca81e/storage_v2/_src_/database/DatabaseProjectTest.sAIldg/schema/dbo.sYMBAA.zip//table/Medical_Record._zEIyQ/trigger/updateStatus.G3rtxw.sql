CREATE TRIGGER updateStatus
ON Medical_Record
AFTER INSERT
AS
        SELECT doctorId FROM inserted
go

